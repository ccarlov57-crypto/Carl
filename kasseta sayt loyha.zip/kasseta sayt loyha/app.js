const typeSelect = document.getElementById('type');
const quantityInput = document.getElementById('quantity');
const totalPriceDisplay = document.getElementById('total-price');

function updatePrice() {
    const pricePerUnit = parseInt(typeSelect.value);
    const quantity = parseInt(quantityInput.value) || 0;
    const total = pricePerUnit * quantity;
    
    totalPriceDisplay.innerText = total.toLocaleString();
}

typeSelect.addEventListener('change', updatePrice);
quantityInput.addEventListener('input', updatePrice);

function sendOrder() {
    const text = `Salom! Men ${quantityInput.value} ta kaseta raqamlashtirmoqchiman. Narxi: ${totalPriceDisplay.innerText} so'm.`;
    const url = `https://t.me/CarlTheBoss_215?text=${encodeURIComponent(text)}`;
    window.location.href = url;
}
// Sahifa yuklanganda elementlarni paydo qilish
window.onload = () => {
    const card = document.querySelector('.card');
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
        card.style.transition = 'all 0.8s ease';
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
    }, 200);
};